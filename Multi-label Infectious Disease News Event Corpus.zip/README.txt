Multi-label Infectious Disease News Event Corpus

The archive contains three files:

1. infectious_diseases_finegrained_grained.txt

The text snippets labelled with fine-grained event types.
The text snippets and the labels are separated by tabs.

2. infectious_diseases_coarse_grained.txt

The text snippets labelled with coarse-grained event types.
The text snippets and the labels are separated by tabs.

3. Annotation_guidelines.pdf

The draft version of the annotation guidelines used by the annotators.